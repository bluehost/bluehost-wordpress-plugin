<main id="main">
	<div class="container">
		<div class="panel panel-default">
			<div class="panel-heading">
				<div class="row">
					<div class="col-xs-12 col-sm-12">
						<ol class="breadcrumb">
							<li>Unable to load items from API. Please try again. <a href="<?php echo esc_url( add_query_arg( array( 'refresh' => rand( 100, 999 ) ) ) ); ?>">Try Again</a></li>
						</ol>
					</div>
				</div>
			</div>
		</div>
	</div>
</main>